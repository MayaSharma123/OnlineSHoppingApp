package com.shoppingapp.OnlineShoppingApp.repository;

import com.shoppingapp.OnlineShoppingApp.model.UserInfo;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
@Transactional
public interface UserInfoRepository extends MongoRepository<UserInfo, String> {
    UserInfo findByEmail(String email);

    Optional<UserInfo> findByLoginId(String loginId);

    UserInfo findByResetPasswordToken(String token);
}
