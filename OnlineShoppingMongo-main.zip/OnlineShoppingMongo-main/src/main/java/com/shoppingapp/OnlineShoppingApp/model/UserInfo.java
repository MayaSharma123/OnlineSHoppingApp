package com.shoppingapp.OnlineShoppingApp.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
public class UserInfo {
    @Id
    private String id;
    private String loginId;
    private String firstName;
    private String lastName;
    private String password;
    private String confirmPassword;
    private String email;
    private String roles;
    private String resetPasswordToken;
    private Long contactNumber;
}
