package com.shoppingapp.OnlineShoppingApp.model;

import jakarta.persistence.Id;
import lombok.Data;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Document(collection = "products")
public class Product {
    @Id
    private String id;
    private int productId;
    private String productName;
    private String productDesc;
    private int price;
    private String features;
    private int quantity;
    private String productStatus;
}
